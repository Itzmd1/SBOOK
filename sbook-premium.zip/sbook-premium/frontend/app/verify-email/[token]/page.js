"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import api from "@/lib/api";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";

export default function VerifyEmailPage() {
  const { token } = useParams();
  const [status, setStatus] = useState("loading"); // loading | success | error
  const [message, setMessage] = useState("");

  useEffect(() => {
    api
      .get(`/auth/verify-email/${token}`)
      .then((res) => {
        setStatus("success");
        setMessage(res.data.message);
      })
      .catch((err) => {
        setStatus("error");
        setMessage(err.message);
      });
  }, [token]);

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-5 text-center">
      {status === "loading" && <Loader2 className="animate-spin text-amber" size={40} />}
      {status === "success" && <CheckCircle2 className="text-success" size={48} />}
      {status === "error" && <XCircle className="text-danger" size={48} />}
      <p className="mt-4 text-ink/70 dark:text-paper/70">{message || "Verifying..."}</p>
      {status !== "loading" && (
        <Link href="/login" className="btn-primary mt-6">Go to login</Link>
      )}
    </div>
  );
}
