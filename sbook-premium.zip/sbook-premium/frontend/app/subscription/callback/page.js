"use client";

import { useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";
import api from "@/lib/api";

export default function PaymentCallbackPage() {
  const params = useSearchParams();
  const router = useRouter();
  const [status, setStatus] = useState("loading"); // loading | success | error
  const [message, setMessage] = useState("");

  useEffect(() => {
    const reference = params.get("reference") || params.get("trxref");
    if (!reference) {
      setStatus("error");
      setMessage("No payment reference found.");
      return;
    }

    api
      .get(`/payments/verify/${reference}`)
      .then((res) => {
        setStatus("success");
        setMessage(res.data.message);
      })
      .catch((err) => {
        setStatus("error");
        setMessage(err.message);
      });
  }, [params]);

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-5 text-center">
      {status === "loading" && (
        <>
          <Loader2 className="animate-spin text-amber" size={40} />
          <p className="mt-4 text-ink/70 dark:text-paper/70">Confirming your payment with Paystack...</p>
        </>
      )}
      {status === "success" && (
        <>
          <CheckCircle2 className="text-success" size={48} />
          <h1 className="mt-4 font-display text-2xl font-semibold">You're premium 🎉</h1>
          <p className="mt-2 text-ink/70 dark:text-paper/70">{message}</p>
          <Link href="/books" className="btn-primary mt-6">Start reading</Link>
        </>
      )}
      {status === "error" && (
        <>
          <XCircle className="text-danger" size={48} />
          <h1 className="mt-4 font-display text-2xl font-semibold">Payment not confirmed</h1>
          <p className="mt-2 text-ink/70 dark:text-paper/70">{message}</p>
          <Link href="/dashboard/subscription" className="btn-primary mt-6">Try again</Link>
        </>
      )}
    </div>
  );
}
