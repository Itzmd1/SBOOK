const faqs = [
  { q: "How much does SBook Premium cost?", a: "Premium access is ₦1,000 per month, billed through Paystack. It covers every book in the library." },
  { q: "How do I pay?", a: "Subscribe from your dashboard and you'll be redirected to Paystack's secure checkout. Your access activates automatically once payment is confirmed." },
  { q: "Can I download books?", a: "Downloads are available for individual books only when the admin has enabled them. Otherwise, books are read in the in-app viewer." },
  { q: "What happens when my subscription expires?", a: "You'll get a reminder email 3 days before expiry. After expiry, book content is locked until you renew." },
  { q: "Can I cancel anytime?", a: "Yes — your subscription simply won't auto-renew. You keep access until the current period ends." },
];

export default function FaqPage() {
  return (
    <div className="mx-auto max-w-3xl px-5 py-16">
      <h1 className="font-display text-3xl font-semibold">Frequently Asked Questions</h1>
      <div className="mt-8 space-y-4">
        {faqs.map((f) => (
          <details key={f.q} className="card p-5 group">
            <summary className="cursor-pointer font-medium marker:content-none">{f.q}</summary>
            <p className="mt-2 text-sm text-ink/70 dark:text-paper/70">{f.a}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
