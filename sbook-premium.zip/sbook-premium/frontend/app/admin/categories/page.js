"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { Trash2 } from "lucide-react";
import api from "@/lib/api";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";
import { adminLinks } from "@/app/admin/page";

function CategoriesContent() {
  const [categories, setCategories] = useState([]);
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);

  const loadCategories = () => {
    api.get("/categories").then((res) => setCategories(res.data.categories));
  };

  useEffect(() => {
    loadCategories();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post("/categories", { name });
      setName("");
      loadCategories();
      toast.success("Category created.");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await api.delete(`/categories/${id}`);
      loadCategories();
      toast.success("Category deleted.");
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Categories</h1>

      <form onSubmit={handleCreate} className="mt-6 flex max-w-md gap-3">
        <input className="input-field" placeholder="New category name" value={name} onChange={(e) => setName(e.target.value)} required />
        <button type="submit" disabled={saving} className="btn-primary shrink-0">Add</button>
      </form>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {categories.map((c) => (
          <div key={c.id} className="card flex items-center justify-between p-4">
            <div>
              <p className="font-medium">{c.name}</p>
              <p className="text-xs text-ink/50 dark:text-paper/50">{c._count?.books ?? 0} books</p>
            </div>
            <button onClick={() => handleDelete(c.id)} className="text-danger hover:opacity-70" aria-label="Delete category">
              <Trash2 size={16} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function AdminCategoriesPage() {
  return (
    <RequireAuth role="ADMIN">
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={adminLinks} title="Admin" />
          <div className="flex-1">
            <CategoriesContent />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
