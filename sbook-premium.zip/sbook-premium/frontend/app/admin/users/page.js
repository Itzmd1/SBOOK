"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { Search } from "lucide-react";
import api from "@/lib/api";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";
import { adminLinks } from "@/app/admin/page";

function UsersContent() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const loadUsers = () => {
    setLoading(true);
    api.get("/admin/users", { params: { search } }).then((res) => setUsers(res.data.users)).finally(() => setLoading(false));
  };

  useEffect(() => {
    const timeout = setTimeout(loadUsers, 300);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const handleToggleSuspend = async (id) => {
    try {
      const { data } = await api.put(`/admin/users/${id}/suspend`);
      toast.success(data.isSuspended ? "User suspended." : "User reinstated.");
      loadUsers();
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Manage Users</h1>

      <div className="relative mt-6 max-w-sm">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/40" size={16} />
        <input className="input-field pl-11" placeholder="Search users..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      {loading ? (
        <p className="mt-6 text-ink/50">Loading...</p>
      ) : (
        <div className="card mt-6 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-ink/5 dark:bg-paper/5 text-ink/50 dark:text-paper/50">
              <tr>
                <th className="px-5 py-3">Name</th>
                <th className="px-5 py-3">Email</th>
                <th className="px-5 py-3">Role</th>
                <th className="px-5 py-3">Verified</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10 dark:divide-paper/10">
              {users.map((u) => (
                <tr key={u.id}>
                  <td className="px-5 py-3">{u.fullName}</td>
                  <td className="px-5 py-3">{u.email}</td>
                  <td className="px-5 py-3">{u.role}</td>
                  <td className="px-5 py-3">{u.isEmailVerified ? "Yes" : "No"}</td>
                  <td className="px-5 py-3">
                    <span className={u.isSuspended ? "text-danger" : "text-success"}>
                      {u.isSuspended ? "Suspended" : "Active"}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    {u.role !== "ADMIN" && (
                      <button onClick={() => handleToggleSuspend(u.id)} className="btn-secondary !px-3 !py-1.5 text-xs">
                        {u.isSuspended ? "Reinstate" : "Suspend"}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function AdminUsersPage() {
  return (
    <RequireAuth role="ADMIN">
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={adminLinks} title="Admin" />
          <div className="flex-1">
            <UsersContent />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
