"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import toast from "react-hot-toast";
import { Plus, Trash2, Pencil, X } from "lucide-react";
import api from "@/lib/api";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";
import { adminLinks } from "@/app/admin/page";

const emptyForm = { title: "", author: "", description: "", categoryId: "", downloadEnabled: false };

function BookFormModal({ book, categories, onClose, onSaved }) {
  const [form, setForm] = useState(
    book
      ? { title: book.title, author: book.author, description: book.description, categoryId: book.categoryId, downloadEnabled: book.downloadEnabled }
      : emptyForm
  );
  const [cover, setCover] = useState(null);
  const [pdf, setPdf] = useState(null);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      if (cover) fd.append("cover", cover);
      if (pdf) fd.append("pdf", pdf);

      if (book) {
        await api.put(`/books/${book.id}`, fd, { headers: { "Content-Type": "multipart/form-data" } });
        toast.success("Book updated.");
      } else {
        if (!cover || !pdf) throw new Error("Cover image and PDF file are both required.");
        await api.post("/books", fd, { headers: { "Content-Type": "multipart/form-data" } });
        toast.success("Book uploaded.");
      }
      onSaved();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/60 p-4">
      <div className="card w-full max-w-lg max-h-[90vh] overflow-y-auto p-6">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold">{book ? "Edit Book" : "Upload New Book"}</h2>
          <button onClick={onClose} aria-label="Close"><X size={20} /></button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <input className="input-field" placeholder="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <input className="input-field" placeholder="Author" required value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} />
          <textarea className="input-field" placeholder="Description" required rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <select className="input-field" required value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>
            <option value="">Select category</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>

          <div>
            <label className="text-sm font-medium">Cover image {book && "(leave blank to keep current)"}</label>
            <input type="file" accept="image/*" className="input-field mt-1" onChange={(e) => setCover(e.target.files[0])} />
          </div>
          <div>
            <label className="text-sm font-medium">Book PDF {book && "(leave blank to keep current)"}</label>
            <input type="file" accept="application/pdf" className="input-field mt-1" onChange={(e) => setPdf(e.target.files[0])} />
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.downloadEnabled} onChange={(e) => setForm({ ...form, downloadEnabled: e.target.checked })} />
            Allow readers to download this book
          </label>

          <button type="submit" disabled={saving} className="btn-primary w-full">
            {saving ? "Saving..." : book ? "Save changes" : "Upload book"}
          </button>
        </form>
      </div>
    </div>
  );
}

function BooksContent() {
  const [books, setBooks] = useState([]);
  const [categories, setCategories] = useState([]);
  const [editingBook, setEditingBook] = useState(undefined); // undefined = closed, null = create, object = edit

  const loadData = () => {
    api.get("/books", { params: { limit: 100 } }).then((res) => setBooks(res.data.books));
    api.get("/categories").then((res) => setCategories(res.data.categories));
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleDelete = async (id) => {
    if (!confirm("Delete this book permanently?")) return;
    try {
      await api.delete(`/books/${id}`);
      toast.success("Book deleted.");
      loadData();
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl font-semibold">Manage Books</h1>
        <button onClick={() => setEditingBook(null)} className="btn-primary">
          <Plus size={16} /> Upload book
        </button>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {books.map((b) => (
          <div key={b.id} className="card flex gap-3 p-4">
            <div className="relative h-24 w-16 shrink-0 overflow-hidden rounded book-spine">
              <Image src={b.coverImageUrl} alt={b.title} fill className="object-cover" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">{b.title}</p>
              <p className="truncate text-xs text-ink/50 dark:text-paper/50">{b.author} · {b.category?.name}</p>
              <div className="mt-2 flex gap-2">
                <button onClick={() => setEditingBook(b)} className="btn-secondary !px-2 !py-1 text-xs"><Pencil size={12} /></button>
                <button onClick={() => handleDelete(b.id)} className="btn-secondary !px-2 !py-1 text-xs text-danger"><Trash2 size={12} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {editingBook !== undefined && (
        <BookFormModal
          book={editingBook}
          categories={categories}
          onClose={() => setEditingBook(undefined)}
          onSaved={() => { setEditingBook(undefined); loadData(); }}
        />
      )}
    </div>
  );
}

export default function AdminBooksPage() {
  return (
    <RequireAuth role="ADMIN">
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={adminLinks} title="Admin" />
          <div className="flex-1">
            <BooksContent />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
