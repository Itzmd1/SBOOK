"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { LayoutDashboard, Users, BookOpen, CreditCard, FolderTree } from "lucide-react";
import api from "@/lib/api";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";

export const adminLinks = [
  { href: "/admin", label: "Analytics", icon: LayoutDashboard },
  { href: "/admin/books", label: "Manage Books", icon: BookOpen },
  { href: "/admin/categories", label: "Categories", icon: FolderTree },
  { href: "/admin/users", label: "Manage Users", icon: Users },
  { href: "/admin/payments", label: "Payments", icon: CreditCard },
];

function AnalyticsContent() {
  const [analytics, setAnalytics] = useState(null);

  useEffect(() => {
    api.get("/admin/analytics").then((res) => setAnalytics(res.data.analytics));
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Analytics</h1>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Total Users", value: analytics?.totalUsers },
          { label: "Active Subscribers", value: analytics?.activeSubscribers },
          { label: "Total Books", value: analytics?.totalBooks },
          { label: "Total Revenue", value: analytics ? `₦${analytics.totalRevenue.toLocaleString()}` : undefined },
        ].map((s) => (
          <div key={s.label} className="card p-6">
            <p className="font-display text-3xl font-semibold">{s.value ?? "—"}</p>
            <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">{s.label}</p>
          </div>
        ))}
      </div>

      <h2 className="mt-10 font-display text-xl font-semibold">Most read books</h2>
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {analytics?.topBooks?.map((b) => (
          <div key={b.id} className="card flex items-center gap-3 p-4">
            <div className="relative h-16 w-12 shrink-0 overflow-hidden rounded book-spine">
              <Image src={b.coverImageUrl} alt={b.title} fill className="object-cover" />
            </div>
            <div className="min-w-0">
              <p className="truncate font-medium">{b.title}</p>
              <p className="text-xs text-ink/50 dark:text-paper/50">{b.viewCount} views</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function AdminPage() {
  return (
    <RequireAuth role="ADMIN">
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={adminLinks} title="Admin" />
          <div className="flex-1">
            <AnalyticsContent />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
