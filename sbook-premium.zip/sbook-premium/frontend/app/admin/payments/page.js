"use client";

import { useEffect, useState } from "react";
import api from "@/lib/api";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";
import { adminLinks } from "@/app/admin/page";

function PaymentsContent() {
  const [payments, setPayments] = useState([]);
  const [subscribers, setSubscribers] = useState([]);
  const [tab, setTab] = useState("payments");

  useEffect(() => {
    api.get("/admin/payments").then((res) => setPayments(res.data.payments));
    api.get("/admin/subscribers").then((res) => setSubscribers(res.data.subscribers));
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Payments & Subscribers</h1>

      <div className="mt-6 flex gap-2">
        {["payments", "subscribers"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`rounded-full px-4 py-2 text-sm font-medium capitalize ${
              tab === t ? "bg-ink text-paper dark:bg-amber dark:text-ink" : "bg-ink/5 dark:bg-paper/10"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "payments" ? (
        <div className="card mt-6 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-ink/5 dark:bg-paper/5 text-ink/50 dark:text-paper/50">
              <tr>
                <th className="px-5 py-3">User</th>
                <th className="px-5 py-3">Reference</th>
                <th className="px-5 py-3">Amount</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10 dark:divide-paper/10">
              {payments.map((p) => (
                <tr key={p.id}>
                  <td className="px-5 py-3">{p.user?.fullName}</td>
                  <td className="px-5 py-3 font-mono text-xs">{p.reference}</td>
                  <td className="px-5 py-3">₦{p.amount.toLocaleString()}</td>
                  <td className="px-5 py-3">{p.status}</td>
                  <td className="px-5 py-3 text-ink/60 dark:text-paper/60">{new Date(p.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="card mt-6 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-ink/5 dark:bg-paper/5 text-ink/50 dark:text-paper/50">
              <tr>
                <th className="px-5 py-3">User</th>
                <th className="px-5 py-3">Email</th>
                <th className="px-5 py-3">Expires</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10 dark:divide-paper/10">
              {subscribers.map((s) => (
                <tr key={s.id}>
                  <td className="px-5 py-3">{s.user?.fullName}</td>
                  <td className="px-5 py-3">{s.user?.email}</td>
                  <td className="px-5 py-3">{new Date(s.endDate).toDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function AdminPaymentsPage() {
  return (
    <RequireAuth role="ADMIN">
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={adminLinks} title="Admin" />
          <div className="flex-1">
            <PaymentsContent />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
