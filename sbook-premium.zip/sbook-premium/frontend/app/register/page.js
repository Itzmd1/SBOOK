"use client";

import { useState } from "react";
import Link from "next/link";
import toast from "react-hot-toast";
import api from "@/lib/api";

export default function RegisterPage() {
  const [form, setForm] = useState({ fullName: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post("/auth/register", form);
      setSubmitted(true);
      toast.success("Account created! Check your email.");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-5 text-center">
        <h1 className="font-display text-3xl font-semibold">Check your inbox 📬</h1>
        <p className="mt-3 text-ink/60 dark:text-paper/60">
          We sent a verification link to <strong>{form.email}</strong>. Verify your email, then log in and subscribe to start reading.
        </p>
        <Link href="/login" className="btn-primary mt-8">Go to login</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-5 py-16">
      <h1 className="font-display text-3xl font-semibold">Create your account</h1>
      <p className="mt-2 text-ink/60 dark:text-paper/60">Join SBook Premium — ₦1,000/month for the whole library.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <input
          required placeholder="Full name" className="input-field"
          value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })}
        />
        <input
          type="email" required placeholder="Email address" className="input-field"
          value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <input
          type="password" required minLength={8} placeholder="Password (min. 8 characters)" className="input-field"
          value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
        />
        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? "Creating account..." : "Create account"}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-ink/60 dark:text-paper/60">
        Already have an account? <Link href="/login" className="text-amber-deep dark:text-amber font-medium">Log in</Link>
      </p>
    </div>
  );
}
