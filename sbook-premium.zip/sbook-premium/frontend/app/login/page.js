"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import { useAuth } from "@/context/AuthContext";

export default function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(form.email, form.password);
      toast.success("Welcome back!");
      router.push(user.role === "ADMIN" ? "/admin" : "/dashboard");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-5 py-16">
      <h1 className="font-display text-3xl font-semibold">Welcome back</h1>
      <p className="mt-2 text-ink/60 dark:text-paper/60">Log in to continue your reading.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <input
          type="email" required placeholder="Email address" className="input-field"
          value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <input
          type="password" required placeholder="Password" className="input-field"
          value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
        />
        <div className="text-right text-sm">
          <Link href="/forgot-password" className="text-amber-deep dark:text-amber">Forgot password?</Link>
        </div>
        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? "Logging in..." : "Log in"}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-ink/60 dark:text-paper/60">
        Don't have an account? <Link href="/register" className="text-amber-deep dark:text-amber font-medium">Sign up</Link>
      </p>
    </div>
  );
}
