import Link from "next/link";
import { BookOpen, Search, Bookmark, ShieldCheck, Sparkles } from "lucide-react";

export default function HomePage() {
  return (
    <div>
      {/* Hero */}
      <section className="mx-auto max-w-7xl px-5 pt-16 pb-24 md:pt-24">
        <div className="grid items-center gap-12 md:grid-cols-2">
          <div className="animate-fadeUp">
            <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-amber/40 bg-amber/10 px-4 py-1.5 text-sm font-medium text-amber-deep dark:text-amber">
              <Sparkles size={14} /> One subscription. Every book on the shelf.
            </p>
            <h1 className="font-display text-4xl font-semibold leading-[1.1] md:text-6xl">
              A library that opens the moment you walk in.
            </h1>
            <p className="mt-6 max-w-lg text-lg text-ink/70 dark:text-paper/70">
              SBook Premium is a reading room for people who read a lot — full-length books,
              a distraction-free viewer, and your place saved wherever you left off.
              ₦1,000 a month, cancel anytime.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/register" className="btn-primary">Start reading — ₦1,000/mo</Link>
              <Link href="/books" className="btn-secondary">Browse the catalog</Link>
            </div>
          </div>

          {/* Signature element: an angled "bookshelf" stack of cards */}
          <div className="relative h-[420px] hidden md:block">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="card book-spine absolute w-56 p-4"
                style={{
                  top: `${i * 34}px`,
                  left: `${i * 44}px`,
                  transform: `rotate(${(i - 1) * 3}deg)`,
                  zIndex: 10 - i,
                }}
              >
                <div className="mb-3 h-40 w-full rounded-md bg-gradient-to-br from-ink to-ink-400" />
                <p className="font-display text-sm font-semibold">Reading, undisturbed</p>
                <p className="text-xs text-ink/50 dark:text-paper/50">Chapter {i + 3}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="border-y border-ink/10 bg-white/60 py-20 dark:border-paper/10 dark:bg-ink-700/40">
        <div className="mx-auto max-w-7xl px-5">
          <h2 className="font-display text-3xl font-semibold text-center">Built for readers, not skimmers</h2>
          <div className="mt-12 grid gap-8 md:grid-cols-4">
            {[
              { icon: Search, title: "Find it fast", copy: "Search by title, author, or browse by category." },
              { icon: BookOpen, title: "Clean PDF viewer", copy: "A quiet, focused reading experience on any device." },
              { icon: Bookmark, title: "Pick up where you left off", copy: "Bookmarks, favorites, and reading progress synced." },
              { icon: ShieldCheck, title: "Secure by design", copy: "Encrypted, rate-limited, and role-protected access." },
            ].map(({ icon: Icon, title, copy }) => (
              <div key={title} className="card p-6">
                <Icon className="text-amber-deep dark:text-amber" />
                <h3 className="mt-4 font-display text-lg font-semibold">{title}</h3>
                <p className="mt-2 text-sm text-ink/60 dark:text-paper/60">{copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="mx-auto max-w-3xl px-5 py-24 text-center">
        <h2 className="font-display text-3xl font-semibold">One plan. Everything included.</h2>
        <div className="card mt-10 mx-auto max-w-sm p-10 book-spine">
          <p className="font-display text-lg font-semibold text-amber-deep dark:text-amber">Premium Monthly</p>
          <p className="mt-2 font-display text-5xl font-semibold">₦1,000<span className="text-lg font-body text-ink/50">/mo</span></p>
          <ul className="mt-6 space-y-2 text-sm text-ink/70 dark:text-paper/70">
            <li>Unlimited access to every book</li>
            <li>Bookmarks, favorites & progress sync</li>
            <li>Cancel or renew anytime</li>
          </ul>
          <Link href="/register" className="btn-primary mt-8 w-full">Subscribe now</Link>
        </div>
      </section>
    </div>
  );
}
