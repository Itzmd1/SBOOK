"use client";

import { useState } from "react";
import toast from "react-hot-toast";
import api from "@/lib/api";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post("/auth/forgot-password", { email });
      setSent(true);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-5 py-16">
      <h1 className="font-display text-3xl font-semibold">Reset your password</h1>
      {sent ? (
        <p className="mt-4 text-ink/60 dark:text-paper/60">
          If an account exists for <strong>{email}</strong>, a reset link is on its way.
        </p>
      ) : (
        <>
          <p className="mt-2 text-ink/60 dark:text-paper/60">We'll email you a link to reset it.</p>
          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <input
              type="email" required placeholder="Email address" className="input-field"
              value={email} onChange={(e) => setEmail(e.target.value)}
            />
            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? "Sending..." : "Send reset link"}
            </button>
          </form>
        </>
      )}
    </div>
  );
}
