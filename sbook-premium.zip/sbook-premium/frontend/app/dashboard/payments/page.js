"use client";

import { useEffect, useState } from "react";
import { LayoutDashboard, CreditCard, Heart, User } from "lucide-react";
import api from "@/lib/api";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";

const links = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/dashboard/subscription", label: "My Subscription", icon: CreditCard },
  { href: "/dashboard/payments", label: "Payment History", icon: CreditCard },
  { href: "/dashboard/saved", label: "Saved Books", icon: Heart },
  { href: "/dashboard/profile", label: "Profile Settings", icon: User },
];

const statusStyles = {
  SUCCESS: "bg-success/10 text-success",
  PENDING: "bg-amber/10 text-amber-deep dark:text-amber",
  FAILED: "bg-danger/10 text-danger",
};

function PaymentsContent() {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/payments/history").then((res) => setPayments(res.data.payments)).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Payment History</h1>

      {loading ? (
        <p className="mt-6 text-ink/50">Loading...</p>
      ) : payments.length === 0 ? (
        <p className="mt-6 text-sm text-ink/50 dark:text-paper/50">No payments yet.</p>
      ) : (
        <div className="card mt-8 overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-ink/5 dark:bg-paper/5 text-ink/50 dark:text-paper/50">
              <tr>
                <th className="px-5 py-3">Reference</th>
                <th className="px-5 py-3">Amount</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10 dark:divide-paper/10">
              {payments.map((p) => (
                <tr key={p.id}>
                  <td className="px-5 py-3 font-mono text-xs">{p.reference}</td>
                  <td className="px-5 py-3">₦{p.amount.toLocaleString()}</td>
                  <td className="px-5 py-3">
                    <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${statusStyles[p.status]}`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-ink/60 dark:text-paper/60">
                    {new Date(p.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function PaymentsPage() {
  return (
    <RequireAuth>
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={links} title="Your Account" />
          <div className="flex-1">
            <PaymentsContent />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
