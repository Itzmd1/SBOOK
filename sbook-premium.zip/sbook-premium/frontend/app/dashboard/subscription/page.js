"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { ShieldCheck, LayoutDashboard, CreditCard, Heart, User } from "lucide-react";
import api from "@/lib/api";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";

const links = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/dashboard/subscription", label: "My Subscription", icon: CreditCard },
  { href: "/dashboard/payments", label: "Payment History", icon: CreditCard },
  { href: "/dashboard/saved", label: "Saved Books", icon: Heart },
  { href: "/dashboard/profile", label: "Profile Settings", icon: User },
];

function SubscriptionContent() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState(false);

  const loadStatus = () => {
    api.get("/payments/subscription-status").then((res) => setStatus(res.data)).finally(() => setLoading(false));
  };

  useEffect(() => {
    loadStatus();
  }, []);

  const handleSubscribe = async () => {
    setPaying(true);
    try {
      const { data } = await api.post("/payments/initialize");
      window.location.href = data.authorizationUrl; // redirect to Paystack checkout
    } catch (err) {
      toast.error(err.message);
      setPaying(false);
    }
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">My Subscription</h1>

      {loading ? (
        <p className="mt-6 text-ink/50">Loading...</p>
      ) : status?.isActive ? (
        <div className="card mt-8 max-w-xl p-8 book-spine">
          <p className="flex items-center gap-2 font-semibold text-success">
            <ShieldCheck size={18} /> Active Premium Subscription
          </p>
          <p className="mt-3 text-sm text-ink/60 dark:text-paper/60">
            Valid until <strong>{new Date(status.subscription.endDate).toDateString()}</strong>. We'll email you a renewal reminder 3 days before it expires.
          </p>
        </div>
      ) : (
        <div className="card mt-8 max-w-xl p-8 book-spine">
          <p className="font-semibold">No active subscription</p>
          <p className="mt-2 text-sm text-ink/60 dark:text-paper/60">
            Subscribe for ₦1,000/month to unlock every book in the library.
          </p>
          <button onClick={handleSubscribe} disabled={paying} className="btn-primary mt-6 w-full">
            {paying ? "Redirecting to Paystack..." : "Pay ₦1,000 with Paystack"}
          </button>
        </div>
      )}
    </div>
  );
}

export default function SubscriptionPage() {
  return (
    <RequireAuth>
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={links} title="Your Account" />
          <div className="flex-1">
            <SubscriptionContent />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
