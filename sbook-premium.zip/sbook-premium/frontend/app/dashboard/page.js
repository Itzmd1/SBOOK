"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { LayoutDashboard, CreditCard, Heart, User, BookOpen } from "lucide-react";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";

const links = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/dashboard/subscription", label: "My Subscription", icon: CreditCard },
  { href: "/dashboard/payments", label: "Payment History", icon: CreditCard },
  { href: "/dashboard/saved", label: "Saved Books", icon: Heart },
  { href: "/dashboard/profile", label: "Profile Settings", icon: User },
];

function DashboardOverview() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [continueReading, setContinueReading] = useState([]);

  useEffect(() => {
    api.get("/users/stats").then((res) => setStats(res.data.stats));
    api.get("/users/continue-reading").then((res) => setContinueReading(res.data.continueReading));
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Welcome back, {user?.fullName?.split(" ")[0]}</h1>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        {[
          { label: "Books started", value: stats?.booksStarted ?? "—" },
          { label: "Books completed", value: stats?.booksCompleted ?? "—" },
          { label: "Favorites", value: stats?.favoritesCount ?? "—" },
        ].map((s) => (
          <div key={s.label} className="card p-6">
            <p className="font-display text-3xl font-semibold">{s.value}</p>
            <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">{s.label}</p>
          </div>
        ))}
      </div>

      <h2 className="mt-10 font-display text-xl font-semibold">Continue reading</h2>
      {continueReading.length === 0 ? (
        <p className="mt-3 text-sm text-ink/50 dark:text-paper/50">
          You haven't started a book yet. <Link href="/books" className="text-amber-deep dark:text-amber">Browse the library</Link>.
        </p>
      ) : (
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {continueReading.map((p) => (
            <Link key={p.id} href={`/books/${p.bookId}`} className="card flex items-center gap-3 p-4">
              <BookOpen className="text-amber-deep dark:text-amber shrink-0" size={20} />
              <div className="min-w-0">
                <p className="truncate font-medium">{p.book.title}</p>
                <p className="text-xs text-ink/50 dark:text-paper/50">{Math.round(p.percentage)}% complete</p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

export default function DashboardPage() {
  return (
    <RequireAuth>
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={links} title="Your Account" />
          <div className="flex-1">
            <DashboardOverview />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
