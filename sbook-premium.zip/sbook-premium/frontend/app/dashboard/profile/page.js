"use client";

import { useState } from "react";
import toast from "react-hot-toast";
import { LayoutDashboard, CreditCard, Heart, User } from "lucide-react";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";

const links = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/dashboard/subscription", label: "My Subscription", icon: CreditCard },
  { href: "/dashboard/payments", label: "Payment History", icon: CreditCard },
  { href: "/dashboard/saved", label: "Saved Books", icon: Heart },
  { href: "/dashboard/profile", label: "Profile Settings", icon: User },
];

function ProfileContent() {
  const { user, refreshUser } = useAuth();
  const [fullName, setFullName] = useState(user?.fullName || "");
  const [savingProfile, setSavingProfile] = useState(false);

  const [passwords, setPasswords] = useState({ currentPassword: "", newPassword: "" });
  const [savingPassword, setSavingPassword] = useState(false);

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await api.put("/users/profile", { fullName });
      await refreshUser();
      toast.success("Profile updated.");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSavingProfile(false);
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    setSavingPassword(true);
    try {
      await api.put("/users/change-password", passwords);
      setPasswords({ currentPassword: "", newPassword: "" });
      toast.success("Password updated.");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSavingPassword(false);
    }
  };

  return (
    <div className="max-w-lg">
      <h1 className="font-display text-3xl font-semibold">Profile Settings</h1>

      <form onSubmit={handleProfileSubmit} className="card mt-8 space-y-4 p-6">
        <p className="font-semibold">Basic info</p>
        <input className="input-field" value={fullName} onChange={(e) => setFullName(e.target.value)} />
        <input className="input-field opacity-60" value={user?.email} disabled />
        <button type="submit" disabled={savingProfile} className="btn-primary">
          {savingProfile ? "Saving..." : "Save changes"}
        </button>
      </form>

      <form onSubmit={handlePasswordSubmit} className="card mt-6 space-y-4 p-6">
        <p className="font-semibold">Change password</p>
        <input
          type="password" required placeholder="Current password" className="input-field"
          value={passwords.currentPassword}
          onChange={(e) => setPasswords({ ...passwords, currentPassword: e.target.value })}
        />
        <input
          type="password" required minLength={8} placeholder="New password" className="input-field"
          value={passwords.newPassword}
          onChange={(e) => setPasswords({ ...passwords, newPassword: e.target.value })}
        />
        <button type="submit" disabled={savingPassword} className="btn-primary">
          {savingPassword ? "Updating..." : "Update password"}
        </button>
      </form>
    </div>
  );
}

export default function ProfilePage() {
  return (
    <RequireAuth>
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={links} title="Your Account" />
          <div className="flex-1">
            <ProfileContent />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
