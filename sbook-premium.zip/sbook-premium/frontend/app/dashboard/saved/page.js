"use client";

import { useEffect, useState } from "react";
import { LayoutDashboard, CreditCard, Heart, User } from "lucide-react";
import api from "@/lib/api";
import RequireAuth from "@/components/RequireAuth";
import DashboardSidebar from "@/components/DashboardSidebar";
import BookCard from "@/components/BookCard";

const links = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/dashboard/subscription", label: "My Subscription", icon: CreditCard },
  { href: "/dashboard/payments", label: "Payment History", icon: CreditCard },
  { href: "/dashboard/saved", label: "Saved Books", icon: Heart },
  { href: "/dashboard/profile", label: "Profile Settings", icon: User },
];

function SavedContent() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/users/saved-books").then((res) => setBooks(res.data.favorites)).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl font-semibold">Saved Books</h1>
      {loading ? (
        <p className="mt-6 text-ink/50">Loading...</p>
      ) : books.length === 0 ? (
        <p className="mt-6 text-sm text-ink/50 dark:text-paper/50">You haven't favorited any books yet.</p>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-5 sm:grid-cols-3">
          {books.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function SavedBooksPage() {
  return (
    <RequireAuth>
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col gap-10 md:flex-row">
          <DashboardSidebar links={links} title="Your Account" />
          <div className="flex-1">
            <SavedContent />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
