export default function PrivacyPage() {
  return (
    <div className="mx-auto max-w-3xl px-5 py-16 prose-sm">
      <h1 className="font-display text-3xl font-semibold">Privacy Policy</h1>
      <div className="mt-6 space-y-4 text-sm leading-relaxed text-ink/70 dark:text-paper/70">
        <p>We collect only what's needed to run your account: your name, email, and payment records from Paystack. We never sell your data.</p>
        <p>Your reading activity (bookmarks, favorites, progress) is stored to power your personal dashboard and is visible only to you and platform admins.</p>
        <p>Passwords are hashed with bcrypt and never stored in plain text. Payment card details are handled entirely by Paystack — we never see or store them.</p>
        <p>You can request account deletion at any time by contacting support.</p>
      </div>
    </div>
  );
}
