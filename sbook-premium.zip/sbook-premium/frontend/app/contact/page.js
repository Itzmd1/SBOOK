"use client";

import { useState } from "react";
import toast from "react-hot-toast";
import { Mail } from "lucide-react";

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    // In production, wire this to a support inbox / ticketing endpoint.
    toast.success("Message sent! Our team will get back to you within 24 hours.");
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <div className="mx-auto max-w-lg px-5 py-16">
      <h1 className="font-display text-3xl font-semibold">Contact Support</h1>
      <p className="mt-2 flex items-center gap-2 text-ink/60 dark:text-paper/60">
        <Mail size={16} /> support@sbook.com
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <input required placeholder="Your name" className="input-field" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input type="email" required placeholder="Your email" className="input-field" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <textarea required rows={4} placeholder="How can we help?" className="input-field" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
        <button type="submit" className="btn-primary w-full">Send message</button>
      </form>
    </div>
  );
}
