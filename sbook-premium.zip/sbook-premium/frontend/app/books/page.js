"use client";

import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import api from "@/lib/api";
import BookCard from "@/components/BookCard";
import { useAuth } from "@/context/AuthContext";

export default function BooksPage() {
  const { user } = useAuth();
  const [books, setBooks] = useState([]);
  const [categories, setCategories] = useState([]);
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/categories").then((res) => setCategories(res.data.categories)).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = {};
    if (search) params.search = search;
    if (categoryId) params.categoryId = categoryId;

    const timeout = setTimeout(() => {
      api
        .get("/books", { params })
        .then((res) => setBooks(res.data.books))
        .finally(() => setLoading(false));
    }, 300); // debounce search

    return () => clearTimeout(timeout);
  }, [search, categoryId]);

  return (
    <div className="mx-auto max-w-7xl px-5 py-12">
      <h1 className="font-display text-3xl font-semibold">Browse the library</h1>

      <div className="mt-6 flex flex-col gap-4 md:flex-row md:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/40 dark:text-paper/40" size={18} />
          <input
            className="input-field pl-11"
            placeholder="Search by title or author..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <select
          className="input-field md:w-56"
          value={categoryId}
          onChange={(e) => setCategoryId(e.target.value)}
        >
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name} ({c._count?.books ?? 0})</option>
          ))}
        </select>
      </div>

      {loading ? (
        <p className="mt-16 text-center text-ink/50 dark:text-paper/50">Loading books...</p>
      ) : books.length === 0 ? (
        <p className="mt-16 text-center text-ink/50 dark:text-paper/50">No books match your search.</p>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {books.map((book) => (
            <BookCard key={book.id} book={book} locked={!user} />
          ))}
        </div>
      )}
    </div>
  );
}
