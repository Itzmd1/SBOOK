"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import toast from "react-hot-toast";
import { Heart, Bookmark, Lock } from "lucide-react";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import PdfViewer from "@/components/PdfViewer";

export default function BookDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const [book, setBook] = useState(null);
  const [subscribed, setSubscribed] = useState(false);
  const [fileUrl, setFileUrl] = useState(null);
  const [downloadEnabled, setDownloadEnabled] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/books/${id}`).then((res) => setBook(res.data.book)).finally(() => setLoading(false));

    if (user) {
      api.get("/payments/subscription-status").then((res) => setSubscribed(res.data.isActive));
    }
  }, [id, user]);

  const handleReadNow = async () => {
    try {
      const { data } = await api.get(`/books/${id}/read`);
      setFileUrl(data.pdfUrl);
      setDownloadEnabled(data.downloadEnabled);
    } catch (err) {
      toast.error(err.message);
    }
  };

  const handleFavorite = async () => {
    try {
      const { data } = await api.post(`/books/${id}/favorite`);
      toast.success(data.favorited ? "Added to favorites" : "Removed from favorites");
    } catch (err) {
      toast.error(err.message);
    }
  };

  if (loading) return <p className="py-24 text-center text-ink/50">Loading...</p>;
  if (!book) return <p className="py-24 text-center text-ink/50">Book not found.</p>;

  return (
    <div className="mx-auto max-w-5xl px-5 py-12">
      <div className="grid gap-10 md:grid-cols-[280px_1fr]">
        <div className="relative aspect-[3/4] w-full overflow-hidden rounded-xl2 shadow-card book-spine">
          <Image src={book.coverImageUrl} alt={book.title} fill className="object-cover" />
        </div>

        <div>
          <p className="text-sm uppercase tracking-wide text-amber-deep dark:text-amber">{book.category?.name}</p>
          <h1 className="mt-1 font-display text-3xl font-semibold">{book.title}</h1>
          <p className="mt-1 text-ink/60 dark:text-paper/60">by {book.author}</p>
          <p className="mt-6 leading-relaxed text-ink/80 dark:text-paper/80">{book.description}</p>

          <div className="mt-8 flex flex-wrap gap-3">
            {!fileUrl && (
              <>
                {!user ? (
                  <Link href="/login" className="btn-primary">Log in to read</Link>
                ) : subscribed ? (
                  <button onClick={handleReadNow} className="btn-primary">Read now</button>
                ) : (
                  <Link href="/dashboard/subscription" className="btn-primary">
                    <Lock size={16} /> Subscribe to read — ₦1,000/mo
                  </Link>
                )}
                {user && (
                  <button onClick={handleFavorite} className="btn-secondary">
                    <Heart size={16} /> Favorite
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {fileUrl && (
        <div className="mt-10">
          <PdfViewer bookId={id} fileUrl={fileUrl} downloadEnabled={downloadEnabled} />
        </div>
      )}
    </div>
  );
}
