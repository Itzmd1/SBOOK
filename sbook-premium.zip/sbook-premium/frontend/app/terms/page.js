export default function TermsPage() {
  return (
    <div className="mx-auto max-w-3xl px-5 py-16">
      <h1 className="font-display text-3xl font-semibold">Terms & Conditions</h1>
      <div className="mt-6 space-y-4 text-sm leading-relaxed text-ink/70 dark:text-paper/70">
        <p>By subscribing to SBook Premium you agree to pay ₦1,000 per 30-day period for access to the book library, processed via Paystack.</p>
        <p>Books are licensed for personal reading only. Downloading is permitted only where explicitly enabled, and redistribution of any book content is prohibited.</p>
        <p>Accounts found violating these terms, including sharing login credentials or attempting to bypass the subscription paywall, may be suspended.</p>
        <p>We may update these terms from time to time; continued use of the platform means you accept the current version.</p>
      </div>
    </div>
  );
}
