"use client";

import Link from "next/link";
import { useState } from "react";
import { BookOpen, Sun, Moon, Menu, X, LayoutDashboard, LogOut } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-ink/10 dark:border-paper/10 bg-paper/90 dark:bg-ink-900/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <Link href="/" className="flex items-center gap-2 font-display text-xl font-semibold">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-ink text-amber dark:bg-amber dark:text-ink">
            <BookOpen size={18} />
          </span>
          SBook <span className="text-amber-deep dark:text-amber">Premium</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link href="/books" className="hover:text-amber-deep dark:hover:text-amber">Browse</Link>
          <Link href="/#pricing" className="hover:text-amber-deep dark:hover:text-amber">Pricing</Link>
          <Link href="/faq" className="hover:text-amber-deep dark:hover:text-amber">FAQ</Link>
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <button onClick={toggleTheme} aria-label="Toggle theme" className="rounded-full p-2 hover:bg-ink/5 dark:hover:bg-paper/10">
            {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {user ? (
            <>
              <Link href={user.role === "ADMIN" ? "/admin" : "/dashboard"} className="btn-secondary !py-2">
                <LayoutDashboard size={16} /> Dashboard
              </Link>
              <button onClick={logout} className="rounded-full p-2 hover:bg-ink/5 dark:hover:bg-paper/10" aria-label="Log out">
                <LogOut size={18} />
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="btn-secondary !py-2">Log in</Link>
              <Link href="/register" className="btn-primary !py-2">Get Premium</Link>
            </>
          )}
        </div>

        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <div className="flex flex-col gap-4 border-t border-ink/10 px-5 py-4 md:hidden dark:border-paper/10">
          <Link href="/books" onClick={() => setOpen(false)}>Browse</Link>
          <Link href="/faq" onClick={() => setOpen(false)}>FAQ</Link>
          {user ? (
            <>
              <Link href={user.role === "ADMIN" ? "/admin" : "/dashboard"} onClick={() => setOpen(false)}>Dashboard</Link>
              <button onClick={logout} className="text-left">Log out</button>
            </>
          ) : (
            <>
              <Link href="/login" onClick={() => setOpen(false)}>Log in</Link>
              <Link href="/register" className="btn-primary w-fit" onClick={() => setOpen(false)}>Get Premium</Link>
            </>
          )}
        </div>
      )}
    </header>
  );
}
