"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";

/** Wrap any private page content with this. Redirects to /login if not authenticated,
 *  and optionally enforces a required role (e.g. "ADMIN"). */
export default function RequireAuth({ children, role }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace("/login");
    } else if (role && user.role !== role) {
      router.replace("/dashboard");
    }
  }, [user, loading, role, router]);

  if (loading || !user || (role && user.role !== role)) {
    return <p className="py-24 text-center text-ink/50 dark:text-paper/50">Loading...</p>;
  }

  return children;
}
