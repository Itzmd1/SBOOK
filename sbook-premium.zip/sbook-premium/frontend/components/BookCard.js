import Link from "next/link";
import Image from "next/image";
import { Lock } from "lucide-react";

export default function BookCard({ book, locked = false }) {
  return (
    <Link
      href={`/books/${book.id}`}
      className="card book-spine group block overflow-hidden animate-fadeUp"
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-ink-50 dark:bg-ink-900">
        <Image
          src={book.coverImageUrl}
          alt={`Cover of ${book.title}`}
          fill
          sizes="(max-width: 768px) 50vw, 22vw"
          className="object-cover transition duration-500 group-hover:scale-105"
        />
        {locked && (
          <div className="absolute inset-0 flex items-center justify-center bg-ink/50 opacity-0 transition group-hover:opacity-100">
            <span className="flex items-center gap-1 rounded-full bg-amber px-3 py-1 text-xs font-semibold text-ink">
              <Lock size={12} /> Premium
            </span>
          </div>
        )}
      </div>
      <div className="p-4">
        <p className="text-xs uppercase tracking-wide text-amber-deep dark:text-amber">
          {book.category?.name}
        </p>
        <h3 className="mt-1 line-clamp-2 font-display text-base font-semibold leading-snug">
          {book.title}
        </h3>
        <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">{book.author}</p>
      </div>
    </Link>
  );
}
