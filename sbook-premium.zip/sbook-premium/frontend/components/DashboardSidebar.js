"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function DashboardSidebar({ links, title }) {
  const pathname = usePathname();

  return (
    <aside className="w-full shrink-0 md:w-56">
      <p className="mb-4 text-xs font-semibold uppercase tracking-wide text-ink/40 dark:text-paper/40">{title}</p>
      <nav className="flex flex-row gap-2 overflow-x-auto md:flex-col md:overflow-visible">
        {links.map(({ href, label, icon: Icon }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-4 py-2.5 text-sm font-medium transition ${
                active
                  ? "bg-ink text-paper dark:bg-amber dark:text-ink"
                  : "text-ink/70 hover:bg-ink/5 dark:text-paper/70 dark:hover:bg-paper/10"
              }`}
            >
              <Icon size={16} /> {label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
