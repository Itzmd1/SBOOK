import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-ink/10 dark:border-paper/10 mt-24">
      <div className="mx-auto max-w-7xl px-5 py-12 grid gap-8 md:grid-cols-4">
        <div>
          <p className="font-display text-lg font-semibold">SBook Premium</p>
          <p className="mt-2 text-sm text-ink/60 dark:text-paper/60">
            A quiet, well-lit room for readers — unlimited books, one simple subscription.
          </p>
        </div>
        <div>
          <p className="font-semibold mb-3 text-sm uppercase tracking-wide text-ink/50 dark:text-paper/50">Product</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/books">Browse Books</Link></li>
            <li><Link href="/#pricing">Pricing</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-semibold mb-3 text-sm uppercase tracking-wide text-ink/50 dark:text-paper/50">Support</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/faq">FAQ</Link></li>
            <li><Link href="/contact">Contact Support</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-semibold mb-3 text-sm uppercase tracking-wide text-ink/50 dark:text-paper/50">Legal</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/privacy">Privacy Policy</Link></li>
            <li><Link href="/terms">Terms & Conditions</Link></li>
          </ul>
        </div>
      </div>
      <p className="text-center text-xs text-ink/40 dark:text-paper/40 pb-8">
        © {new Date().getFullYear()} SBook Premium. All rights reserved.
      </p>
    </footer>
  );
}
