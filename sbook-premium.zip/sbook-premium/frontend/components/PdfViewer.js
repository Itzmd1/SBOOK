"use client";

import { useState, useEffect, useCallback } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/esm/Page/AnnotationLayer.css";
import "react-pdf/dist/esm/Page/TextLayer.css";
import { ChevronLeft, ChevronRight, Download } from "lucide-react";
import api from "@/lib/api";

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

export default function PdfViewer({ bookId, fileUrl, downloadEnabled, initialPage = 1 }) {
  const [numPages, setNumPages] = useState(null);
  const [pageNumber, setPageNumber] = useState(initialPage);

  // Debounced progress save so we don't hammer the API on every page flip
  useEffect(() => {
    if (!numPages) return;
    const timeout = setTimeout(() => {
      api.put(`/books/${bookId}/progress`, { currentPage: pageNumber, totalPages: numPages }).catch(() => {});
    }, 800);
    return () => clearTimeout(timeout);
  }, [pageNumber, numPages, bookId]);

  const onLoadSuccess = useCallback(({ numPages }) => setNumPages(numPages), []);

  return (
    <div className="card flex flex-col items-center p-4">
      <Document
        file={fileUrl}
        onLoadSuccess={onLoadSuccess}
        loading={<p className="py-20 text-ink/50">Loading document...</p>}
        error={<p className="py-20 text-danger">Couldn't load this PDF.</p>}
      >
        <Page pageNumber={pageNumber} width={Math.min(700, typeof window !== "undefined" ? window.innerWidth - 64 : 700)} />
      </Document>

      <div className="mt-4 flex items-center gap-4">
        <button
          disabled={pageNumber <= 1}
          onClick={() => setPageNumber((p) => p - 1)}
          className="btn-secondary !px-3 !py-2 disabled:opacity-40"
        >
          <ChevronLeft size={16} />
        </button>
        <span className="text-sm text-ink/60 dark:text-paper/60">
          Page {pageNumber} of {numPages || "…"}
        </span>
        <button
          disabled={numPages && pageNumber >= numPages}
          onClick={() => setPageNumber((p) => p + 1)}
          className="btn-secondary !px-3 !py-2 disabled:opacity-40"
        >
          <ChevronRight size={16} />
        </button>

        {downloadEnabled && (
          <a href={fileUrl} download className="btn-secondary !px-3 !py-2">
            <Download size={16} />
          </a>
        )}
      </div>
    </div>
  );
}
