/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        // --- SBook Premium design tokens ---
        ink: {
          DEFAULT: "#14213D", // deep navy - primary brand / dark surfaces
          50: "#EEF1F6",
          100: "#D5DCE8",
          400: "#3C4E73",
          700: "#1B2A4A",
          900: "#0C1526",
        },
        paper: {
          DEFAULT: "#FAF7F0", // warm cream - light mode background
          dark: "#F1ECE0",
        },
        amber: {
          DEFAULT: "#E8A33D", // premium accent - spine gold
          soft: "#F4C878",
          deep: "#C97E1E",
        },
        success: "#2F9E68",
        danger: "#D64545",
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "Georgia", "serif"],
        body: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(20,33,61,0.06), 0 8px 24px -8px rgba(20,33,61,0.12)",
        spine: "inset 6px 0 0 0 var(--tw-shadow-color)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: 0, transform: "translateY(8px)" },
          "100%": { opacity: 1, transform: "translateY(0)" },
        },
      },
      animation: {
        fadeUp: "fadeUp 0.5s ease-out both",
      },
    },
  },
  plugins: [],
};
