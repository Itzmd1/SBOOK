# SBook Premium

A subscription-gated digital book platform. Users pay ₦1,000/month (via Paystack) to unlock
the full library; without an active subscription, book content stays locked behind a paywall.

This repository is a **production-grade starter**, not a fully polished, battle-tested product.
The architecture, security middleware, and core flows (auth, payments, paywall, admin) are real
and wired end-to-end. Before going live, read the **"What to finish before production"** section
at the bottom — a few things need your real credentials and a security review to be launch-ready.

---

## Stack

| Layer            | Choice                                             |
|-------------------|-----------------------------------------------------|
| Frontend          | Next.js 14 (App Router) + React + Tailwind CSS       |
| Backend           | Node.js + Express.js                                |
| Database          | PostgreSQL via Prisma ORM                            |
| Auth              | JWT (httpOnly cookies) + email verification          |
| Payments          | Paystack (NGN)                                       |
| File storage      | Cloudinary (book covers + PDFs)                      |
| Email             | Nodemailer (any SMTP provider)                        |

## Project structure

```
sbook-premium/
├── backend/
│   ├── src/
│   │   ├── config/        # Prisma client, Cloudinary config
│   │   ├── controllers/   # Route handlers (auth, books, payments, admin, users)
│   │   ├── middleware/    # auth (JWT), rbac, rate limiting, upload, error handling
│   │   ├── routes/        # Express routers
│   │   ├── scripts/       # admin seed script, subscription expiry cron job
│   │   ├── utils/         # email templates, token generation, cloudinary upload
│   │   ├── prisma/schema.prisma
│   │   └── server.js
│   └── package.json
└── frontend/
    ├── app/                # Next.js App Router pages (public, auth, dashboard, admin)
    ├── components/         # Navbar, BookCard, PdfViewer, DashboardSidebar, etc.
    ├── context/            # AuthContext, ThemeContext (dark/light mode)
    ├── lib/api.js          # Axios client (cookie-based auth)
    └── package.json
```

## Core flows implemented

- **Auth**: register → email verification link → login (JWT in httpOnly cookie) → forgot/reset password.
- **Paywall**: `GET /api/books/:id/read` is the only endpoint that returns the actual PDF URL, and
  it's protected by `requireActiveSubscription` middleware — no active, unexpired subscription, no file.
  The public book-detail endpoint deliberately strips `pdfUrl` from its response.
- **Subscription**: `POST /api/payments/initialize` creates a PENDING subscription + Paystack
  transaction, redirects to Paystack checkout, then either the frontend callback page
  (`/subscription/callback`) or Paystack's webhook (`/api/payments/webhook`, signature-verified)
  activates the subscription for 30 days.
- **Renewal reminders + auto-expiry**: a daily cron job (`node-cron`, see `server.js`) expires
  subscriptions past `endDate` and emails users 3 days before expiry.
- **Admin**: upload/edit/delete books (Cloudinary), manage categories, view/suspend users,
  view subscribers & payment history, analytics dashboard (revenue, signups, top books).
- **RBAC**: `requireRole("ADMIN")` middleware guards all `/api/admin/*` routes and book mutation routes.

## Security measures in place

- Passwords hashed with bcrypt (12 rounds)
- JWT stored in an httpOnly, sameSite=strict cookie (mitigates XSS token theft + CSRF)
- `helmet`, `hpp`, `xss-clean`, `express-mongo-sanitize` on every request
- Rate limiting: strict on auth routes (10 req/15min), general API limiter elsewhere
- SQL injection protection via Prisma's parameterized queries (no raw string SQL except one
  read-only aggregate query in analytics, which takes no user input)
- Paystack webhook signature verification via HMAC-SHA512
- Generic error messages on login/forgot-password to prevent account enumeration

## Getting started

### 1. Backend

```bash
cd backend
cp .env.example .env      # fill in your real DB, JWT secret, Paystack keys, Cloudinary, SMTP
npm install
npx prisma migrate dev --name init
npm run seed               # creates the default admin account
npm run dev                 # http://localhost:5000
```

Default admin login (from `.env` — change immediately after first login):
```
Email: admin@sbook.com
Password: Admin@12345
```

### 2. Frontend

```bash
cd frontend
cp .env.local.example .env.local   # set NEXT_PUBLIC_API_URL
npm install
npm run dev                          # http://localhost:3000
```

### 3. Paystack setup

1. Create a Paystack account, grab your test secret/public keys from the dashboard.
2. Set `PAYSTACK_SECRET_KEY`, `PAYSTACK_PUBLIC_KEY` in `backend/.env`.
3. In the Paystack dashboard, add a webhook pointing to
   `https://your-api-domain.com/api/payments/webhook` and use the same secret key for
   `PAYSTACK_WEBHOOK_SECRET`.
4. Test with Paystack's test cards before going live.

### 4. Cloudinary setup

Create a free Cloudinary account, grab your cloud name/API key/secret from the dashboard,
and set them in `backend/.env`. Book covers go to `sbook/covers`, PDFs to `sbook/pdfs`
(uploaded as `resource_type: raw`).

### 5. Email (SMTP)

Any SMTP provider works (Gmail app password, SendGrid, Mailtrap for testing, etc.) — set
`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `EMAIL_FROM` in `backend/.env`.

## Database schema

See `backend/src/prisma/schema.prisma` for the full schema. Core tables: `User`, `Category`,
`Book`, `Subscription`, `Payment`, `Bookmark`, `Favorite`, `ReadingProgress`, `Notification`.
Run `npx prisma studio` from `backend/` for a visual DB browser during development.

## Deployment notes

- **Backend**: any Node host (Render, Railway, Fly.io, a VPS). Put it behind HTTPS — set
  `NODE_ENV=production` so cookies are marked `secure`. Use `npm run prisma:deploy` for migrations
  in CI/CD rather than `migrate dev`.
- **Frontend**: deploys cleanly to Vercel. Set `NEXT_PUBLIC_API_URL` to your deployed backend URL.
- **Database**: any managed Postgres (Supabase, Railway, Neon, RDS).
- Put both behind HTTPS — the `Secure` cookie flag and CORS config assume it in production.

## What to finish before production

This is a strong, working foundation — but a few things are stubbed or need your judgment before
this goes live with real money and real users:

- **CSRF**: cookies are `sameSite=strict` which covers most CSRF cases for this app's shape, but
  if you add cross-site form posts or third-party embeds, add an explicit CSRF token check
  (the `csurf` package is already in `package.json`, just needs wiring into state-changing routes).
- **Email deliverability**: swap the SMTP placeholder for a real transactional provider
  (SendGrid/Postmark/SES) before launch — inbox placement matters for verification/reset emails.
- **PDF security**: Cloudinary URLs for `raw` resources are unsigned by default in this scaffold —
  for stronger protection against link-sharing, switch to Cloudinary's signed URLs with short
  expiry, generated per-request in `getBookFile`.
- **Automated tests**: none are included yet — add integration tests around the paywall gate and
  payment verification logic first, since that's where a bug costs money.
- **Load testing / rate limit tuning**: the rate limits are reasonable defaults, not tuned for
  your actual traffic.
- **Legal review**: the Terms/Privacy pages are starting drafts, not legal advice — have them
  reviewed before launch.
