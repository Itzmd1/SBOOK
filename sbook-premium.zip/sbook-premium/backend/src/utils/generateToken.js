const jwt = require("jsonwebtoken");

/**
 * Sign a JWT for a given user id + role, set it as an httpOnly cookie,
 * and return the raw token as well (useful for mobile / non-cookie clients).
 */
function generateToken(res, userId, role) {
  const token = jwt.sign({ id: userId, role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });

  const cookieDays = Number(process.env.JWT_COOKIE_EXPIRES_DAYS || 7);

  res.cookie("token", token, {
    httpOnly: true, // not accessible via client-side JS -> mitigates XSS token theft
    secure: process.env.NODE_ENV === "production", // HTTPS only in production
    sameSite: "strict", // mitigates CSRF
    maxAge: cookieDays * 24 * 60 * 60 * 1000,
  });

  return token;
}

module.exports = generateToken;
