const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  },
});

/**
 * Send a transactional email.
 * @param {{to: string, subject: string, html: string}} options
 */
async function sendEmail({ to, subject, html }) {
  await transporter.sendMail({
    from: process.env.EMAIL_FROM || "SBook Premium <no-reply@sbook.com>",
    to,
    subject,
    html,
  });
}

function verificationEmailTemplate(name, verifyUrl) {
  return `
  <div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:24px;border:1px solid #eee;border-radius:12px">
    <h2 style="color:#14213D">Welcome to SBook Premium, ${name} 👋</h2>
    <p>Please confirm your email address to activate your account.</p>
    <a href="${verifyUrl}" style="display:inline-block;background:#E8A33D;color:#14213D;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;margin:16px 0">Verify Email</a>
    <p>If the button doesn't work, copy this link into your browser:</p>
    <p style="word-break:break-all;color:#555">${verifyUrl}</p>
    <p>This link expires in 24 hours.</p>
  </div>`;
}

function resetPasswordEmailTemplate(name, resetUrl) {
  return `
  <div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:24px;border:1px solid #eee;border-radius:12px">
    <h2 style="color:#14213D">Password Reset Request</h2>
    <p>Hi ${name}, we received a request to reset your password.</p>
    <a href="${resetUrl}" style="display:inline-block;background:#E8A33D;color:#14213D;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;margin:16px 0">Reset Password</a>
    <p>If you didn't request this, you can safely ignore this email. This link expires in 1 hour.</p>
  </div>`;
}

function subscriptionReceiptTemplate(name, amount, endDate) {
  return `
  <div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:24px;border:1px solid #eee;border-radius:12px">
    <h2 style="color:#14213D">Payment Successful ✅</h2>
    <p>Hi ${name}, your Premium Monthly Subscription payment of ₦${amount} was successful.</p>
    <p>Your subscription is active until <strong>${new Date(endDate).toDateString()}</strong>.</p>
    <p>Happy reading!</p>
  </div>`;
}

function renewalReminderTemplate(name, endDate) {
  return `
  <div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:24px;border:1px solid #eee;border-radius:12px">
    <h2 style="color:#14213D">Your subscription is expiring soon</h2>
    <p>Hi ${name}, your SBook Premium subscription expires on <strong>${new Date(endDate).toDateString()}</strong>.</p>
    <p>Renew now to keep uninterrupted access to your library.</p>
  </div>`;
}

module.exports = {
  sendEmail,
  verificationEmailTemplate,
  resetPasswordEmailTemplate,
  subscriptionReceiptTemplate,
  renewalReminderTemplate,
};
