const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const asyncHandler = require("express-async-handler");
const prisma = require("../config/db");
const generateToken = require("../utils/generateToken");
const {
  sendEmail,
  verificationEmailTemplate,
  resetPasswordEmailTemplate,
} = require("../utils/sendEmail");

function publicUser(user) {
  const { password, emailVerifyToken, resetPasswordToken, ...safe } = user;
  return safe;
}

// @desc   Register new user + send verification email
// @route  POST /api/auth/register
// @access Public
const register = asyncHandler(async (req, res) => {
  const { fullName, email, password } = req.body;

  if (!fullName || !email || !password) {
    res.status(400);
    throw new Error("Full name, email and password are required.");
  }
  if (password.length < 8) {
    res.status(400);
    throw new Error("Password must be at least 8 characters.");
  }

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) {
    res.status(409);
    throw new Error("An account with this email already exists.");
  }

  const hashedPassword = await bcrypt.hash(password, 12);
  const verifyToken = crypto.randomBytes(32).toString("hex");
  const hashedVerifyToken = crypto.createHash("sha256").update(verifyToken).digest("hex");

  const user = await prisma.user.create({
    data: {
      fullName,
      email: email.toLowerCase(),
      password: hashedPassword,
      emailVerifyToken: hashedVerifyToken,
      emailVerifyExpires: new Date(Date.now() + 24 * 60 * 60 * 1000),
    },
  });

  const verifyUrl = `${process.env.CLIENT_URL}/verify-email/${verifyToken}`;
  try {
    await sendEmail({
      to: user.email,
      subject: "Verify your SBook Premium account",
      html: verificationEmailTemplate(user.fullName, verifyUrl),
    });
  } catch (err) {
    // Registration still succeeds; user can request a resend later.
    console.error("Failed to send verification email:", err.message);
  }

  res.status(201).json({
    success: true,
    message: "Account created. Please check your email to verify your account.",
    user: publicUser(user),
  });
});

// @desc   Verify email via token
// @route  GET /api/auth/verify-email/:token
// @access Public
const verifyEmail = asyncHandler(async (req, res) => {
  const hashedToken = crypto.createHash("sha256").update(req.params.token).digest("hex");

  const user = await prisma.user.findFirst({
    where: { emailVerifyToken: hashedToken, emailVerifyExpires: { gt: new Date() } },
  });

  if (!user) {
    res.status(400);
    throw new Error("Verification link is invalid or has expired.");
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { isEmailVerified: true, emailVerifyToken: null, emailVerifyExpires: null },
  });

  res.json({ success: true, message: "Email verified successfully. You can now log in." });
});

// @desc   Resend verification email
// @route  POST /api/auth/resend-verification
// @access Public
const resendVerification = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const user = await prisma.user.findUnique({ where: { email: email?.toLowerCase() } });

  // Don't reveal whether the account exists
  if (!user || user.isEmailVerified) {
    return res.json({
      success: true,
      message: "If an account exists and is unverified, a new email has been sent.",
    });
  }

  const verifyToken = crypto.randomBytes(32).toString("hex");
  const hashedVerifyToken = crypto.createHash("sha256").update(verifyToken).digest("hex");

  await prisma.user.update({
    where: { id: user.id },
    data: {
      emailVerifyToken: hashedVerifyToken,
      emailVerifyExpires: new Date(Date.now() + 24 * 60 * 60 * 1000),
    },
  });

  const verifyUrl = `${process.env.CLIENT_URL}/verify-email/${verifyToken}`;
  await sendEmail({
    to: user.email,
    subject: "Verify your SBook Premium account",
    html: verificationEmailTemplate(user.fullName, verifyUrl),
  });

  res.json({ success: true, message: "If an account exists and is unverified, a new email has been sent." });
});

// @desc   Login
// @route  POST /api/auth/login
// @access Public
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400);
    throw new Error("Email and password are required.");
  }

  const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });

  // Generic error message to avoid leaking which accounts exist
  if (!user || !(await bcrypt.compare(password, user.password))) {
    res.status(401);
    throw new Error("Invalid email or password.");
  }

  if (user.isSuspended) {
    res.status(403);
    throw new Error("Your account has been suspended. Contact support.");
  }

  if (!user.isEmailVerified) {
    res.status(403);
    throw new Error("Please verify your email before logging in.");
  }

  const token = generateToken(res, user.id, user.role);

  res.json({ success: true, token, user: publicUser(user) });
});

// @desc   Logout
// @route  POST /api/auth/logout
// @access Private
const logout = asyncHandler(async (req, res) => {
  res.clearCookie("token");
  res.json({ success: true, message: "Logged out." });
});

// @desc   Forgot password - send reset link
// @route  POST /api/auth/forgot-password
// @access Public
const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const user = await prisma.user.findUnique({ where: { email: email?.toLowerCase() } });

  // Always respond the same way to avoid account enumeration
  const genericResponse = {
    success: true,
    message: "If an account with that email exists, a reset link has been sent.",
  };

  if (!user) return res.json(genericResponse);

  const resetToken = crypto.randomBytes(32).toString("hex");
  const hashedToken = crypto.createHash("sha256").update(resetToken).digest("hex");

  await prisma.user.update({
    where: { id: user.id },
    data: {
      resetPasswordToken: hashedToken,
      resetPasswordExpires: new Date(Date.now() + 60 * 60 * 1000), // 1 hour
    },
  });

  const resetUrl = `${process.env.CLIENT_URL}/reset-password/${resetToken}`;
  try {
    await sendEmail({
      to: user.email,
      subject: "Reset your SBook Premium password",
      html: resetPasswordEmailTemplate(user.fullName, resetUrl),
    });
  } catch (err) {
    console.error("Failed to send reset email:", err.message);
  }

  res.json(genericResponse);
});

// @desc   Reset password via token
// @route  POST /api/auth/reset-password/:token
// @access Public
const resetPassword = asyncHandler(async (req, res) => {
  const { password } = req.body;
  if (!password || password.length < 8) {
    res.status(400);
    throw new Error("Password must be at least 8 characters.");
  }

  const hashedToken = crypto.createHash("sha256").update(req.params.token).digest("hex");
  const user = await prisma.user.findFirst({
    where: { resetPasswordToken: hashedToken, resetPasswordExpires: { gt: new Date() } },
  });

  if (!user) {
    res.status(400);
    throw new Error("Reset link is invalid or has expired.");
  }

  const hashedPassword = await bcrypt.hash(password, 12);
  await prisma.user.update({
    where: { id: user.id },
    data: { password: hashedPassword, resetPasswordToken: null, resetPasswordExpires: null },
  });

  res.json({ success: true, message: "Password reset successfully. Please log in." });
});

// @desc   Get current authenticated user
// @route  GET /api/auth/me
// @access Private
const getMe = asyncHandler(async (req, res) => {
  res.json({ success: true, user: publicUser(req.user) });
});

module.exports = {
  register,
  verifyEmail,
  resendVerification,
  login,
  logout,
  forgotPassword,
  resetPassword,
  getMe,
};
