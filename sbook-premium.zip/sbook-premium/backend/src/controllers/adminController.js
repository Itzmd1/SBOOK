const asyncHandler = require("express-async-handler");
const prisma = require("../config/db");

// @desc   List all users (paginated, searchable)
// @route  GET /api/admin/users
// @access Private/Admin
const getUsers = asyncHandler(async (req, res) => {
  const { search, page = 1, limit = 20 } = req.query;
  const where = search
    ? { OR: [{ fullName: { contains: search, mode: "insensitive" } }, { email: { contains: search, mode: "insensitive" } }] }
    : {};

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      where,
      select: {
        id: true, fullName: true, email: true, role: true, isEmailVerified: true,
        isSuspended: true, createdAt: true,
      },
      orderBy: { createdAt: "desc" },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
    }),
    prisma.user.count({ where }),
  ]);

  res.json({ success: true, users, total, page: Number(page), pages: Math.ceil(total / limit) });
});

// @desc   Suspend or unsuspend a user
// @route  PUT /api/admin/users/:id/suspend
// @access Private/Admin
const toggleSuspendUser = asyncHandler(async (req, res) => {
  const target = await prisma.user.findUnique({ where: { id: req.params.id } });
  if (!target) {
    res.status(404);
    throw new Error("User not found.");
  }
  if (target.role === "ADMIN") {
    res.status(400);
    throw new Error("Cannot suspend an admin account.");
  }

  const updated = await prisma.user.update({
    where: { id: req.params.id },
    data: { isSuspended: !target.isSuspended },
  });

  res.json({ success: true, isSuspended: updated.isSuspended });
});

// @desc   List active subscribers
// @route  GET /api/admin/subscribers
// @access Private/Admin
const getSubscribers = asyncHandler(async (req, res) => {
  const subscribers = await prisma.subscription.findMany({
    where: { status: "ACTIVE", endDate: { gt: new Date() } },
    include: { user: { select: { id: true, fullName: true, email: true } } },
    orderBy: { endDate: "desc" },
  });
  res.json({ success: true, subscribers });
});

// @desc   List all payments
// @route  GET /api/admin/payments
// @access Private/Admin
const getPayments = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const [payments, total] = await Promise.all([
    prisma.payment.findMany({
      include: { user: { select: { fullName: true, email: true } } },
      orderBy: { createdAt: "desc" },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
    }),
    prisma.payment.count(),
  ]);
  res.json({ success: true, payments, total, page: Number(page), pages: Math.ceil(total / limit) });
});

// @desc   Analytics dashboard summary
// @route  GET /api/admin/analytics
// @access Private/Admin
const getAnalytics = asyncHandler(async (req, res) => {
  const [totalUsers, activeSubscribers, totalBooks, revenueAgg, monthlySignups] = await Promise.all([
    prisma.user.count({ where: { role: "USER" } }),
    prisma.subscription.count({ where: { status: "ACTIVE", endDate: { gt: new Date() } } }),
    prisma.book.count(),
    prisma.payment.aggregate({ where: { status: "SUCCESS" }, _sum: { amount: true } }),
    prisma.$queryRaw`
      SELECT to_char("createdAt", 'YYYY-MM') AS month, COUNT(*)::int AS count
      FROM "User"
      GROUP BY month
      ORDER BY month DESC
      LIMIT 6
    `,
  ]);

  const topBooks = await prisma.book.findMany({
    orderBy: { viewCount: "desc" },
    take: 5,
    select: { id: true, title: true, viewCount: true, coverImageUrl: true },
  });

  res.json({
    success: true,
    analytics: {
      totalUsers,
      activeSubscribers,
      totalBooks,
      totalRevenue: revenueAgg._sum.amount || 0,
      monthlySignups,
      topBooks,
    },
  });
});

module.exports = { getUsers, toggleSuspendUser, getSubscribers, getPayments, getAnalytics };
