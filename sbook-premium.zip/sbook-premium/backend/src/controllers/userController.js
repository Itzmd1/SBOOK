const bcrypt = require("bcryptjs");
const asyncHandler = require("express-async-handler");
const prisma = require("../config/db");
const { uploadToCloudinary } = require("../utils/cloudinaryUpload");

// @desc   Update profile (name / avatar)
// @route  PUT /api/users/profile
// @access Private
const updateProfile = asyncHandler(async (req, res) => {
  const { fullName } = req.body;
  const data = { ...(fullName && { fullName }) };

  if (req.file) {
    const result = await uploadToCloudinary(req.file.buffer, "sbook/avatars", "image");
    data.avatarUrl = result.secure_url;
  }

  const user = await prisma.user.update({ where: { id: req.user.id }, data });
  const { password, ...safe } = user;
  res.json({ success: true, user: safe });
});

// @desc   Change password
// @route  PUT /api/users/change-password
// @access Private
const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = await prisma.user.findUnique({ where: { id: req.user.id } });

  if (!(await bcrypt.compare(currentPassword, user.password))) {
    res.status(401);
    throw new Error("Current password is incorrect.");
  }
  if (!newPassword || newPassword.length < 8) {
    res.status(400);
    throw new Error("New password must be at least 8 characters.");
  }

  const hashed = await bcrypt.hash(newPassword, 12);
  await prisma.user.update({ where: { id: user.id }, data: { password: hashed } });
  res.json({ success: true, message: "Password updated." });
});

// @desc   Get saved books (favorites + bookmarks)
// @route  GET /api/users/saved-books
// @access Private
const getSavedBooks = asyncHandler(async (req, res) => {
  const favorites = await prisma.favorite.findMany({
    where: { userId: req.user.id },
    include: { book: { include: { category: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ success: true, favorites: favorites.map((f) => f.book) });
});

// @desc   Get "continue reading" list
// @route  GET /api/users/continue-reading
// @access Private
const getContinueReading = asyncHandler(async (req, res) => {
  const progress = await prisma.readingProgress.findMany({
    where: { userId: req.user.id, percentage: { lt: 100 } },
    include: { book: true },
    orderBy: { lastReadAt: "desc" },
    take: 10,
  });
  res.json({ success: true, continueReading: progress });
});

// @desc   Get reading statistics
// @route  GET /api/users/stats
// @access Private
const getReadingStats = asyncHandler(async (req, res) => {
  const [booksStarted, booksCompleted, favoritesCount] = await Promise.all([
    prisma.readingProgress.count({ where: { userId: req.user.id } }),
    prisma.readingProgress.count({ where: { userId: req.user.id, percentage: { gte: 100 } } }),
    prisma.favorite.count({ where: { userId: req.user.id } }),
  ]);
  res.json({ success: true, stats: { booksStarted, booksCompleted, favoritesCount } });
});

// @desc   Get in-app notifications
// @route  GET /api/users/notifications
// @access Private
const getNotifications = asyncHandler(async (req, res) => {
  const notifications = await prisma.notification.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: "desc" },
    take: 30,
  });
  res.json({ success: true, notifications });
});

module.exports = {
  updateProfile,
  changePassword,
  getSavedBooks,
  getContinueReading,
  getReadingStats,
  getNotifications,
};
