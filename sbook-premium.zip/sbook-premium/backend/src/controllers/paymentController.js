const crypto = require("crypto");
const https = require("https");
const asyncHandler = require("express-async-handler");
const prisma = require("../config/db");
const { sendEmail, subscriptionReceiptTemplate } = require("../utils/sendEmail");

const PAYSTACK_HOST = "api.paystack.co";

/** Minimal Paystack HTTPS helper (avoids adding an extra HTTP client dependency) */
function paystackRequest(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const options = {
      hostname: PAYSTACK_HOST,
      port: 443,
      path,
      method,
      headers: {
        Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
        "Content-Type": "application/json",
      },
    };

    const reqst = https.request(options, (resp) => {
      let raw = "";
      resp.on("data", (chunk) => (raw += chunk));
      resp.on("end", () => {
        try {
          resolve(JSON.parse(raw));
        } catch (e) {
          reject(e);
        }
      });
    });

    reqst.on("error", reject);
    if (data) reqst.write(data);
    reqst.end();
  });
}

// @desc   Initialize a Paystack transaction for the premium subscription
// @route  POST /api/payments/initialize
// @access Private
const initializePayment = asyncHandler(async (req, res) => {
  const amountNaira = Number(process.env.SUBSCRIPTION_AMOUNT_NGN || 1000);
  const reference = `sbook_${req.user.id}_${Date.now()}`;

  const subscription = await prisma.subscription.create({
    data: {
      userId: req.user.id,
      plan: "PREMIUM_MONTHLY",
      amount: amountNaira,
      status: "PENDING",
    },
  });

  await prisma.payment.create({
    data: {
      userId: req.user.id,
      subscriptionId: subscription.id,
      reference,
      amount: amountNaira,
      currency: "NGN",
      status: "PENDING",
    },
  });

  const paystackRes = await paystackRequest("POST", "/transaction/initialize", {
    email: req.user.email,
    amount: amountNaira * 100, // kobo
    reference,
    callback_url: `${process.env.CLIENT_URL}/subscription/callback`,
    metadata: { userId: req.user.id, subscriptionId: subscription.id },
  });

  if (!paystackRes.status) {
    res.status(502);
    throw new Error(paystackRes.message || "Failed to initialize payment with Paystack.");
  }

  res.json({
    success: true,
    authorizationUrl: paystackRes.data.authorization_url,
    reference,
  });
});

/** Shared logic: verify a reference with Paystack and activate subscription if successful. */
async function verifyAndActivate(reference) {
  const verifyRes = await paystackRequest("GET", `/transaction/verify/${reference}`);

  const payment = await prisma.payment.findUnique({ where: { reference } });
  if (!payment) return { ok: false, reason: "Payment record not found." };

  if (!verifyRes.status || verifyRes.data.status !== "success") {
    await prisma.payment.update({
      where: { reference },
      data: { status: "FAILED", paystackResponse: verifyRes },
    });
    if (payment.subscriptionId) {
      await prisma.subscription.update({
        where: { id: payment.subscriptionId },
        data: { status: "CANCELLED" },
      });
    }
    return { ok: false, reason: "Payment was not successful." };
  }

  const startDate = new Date();
  const endDate = new Date(startDate.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days

  await prisma.$transaction([
    prisma.payment.update({
      where: { reference },
      data: { status: "SUCCESS", paystackResponse: verifyRes },
    }),
    prisma.subscription.update({
      where: { id: payment.subscriptionId },
      data: { status: "ACTIVE", startDate, endDate, reminderSent: false },
    }),
  ]);

  const user = await prisma.user.findUnique({ where: { id: payment.userId } });
  try {
    await sendEmail({
      to: user.email,
      subject: "SBook Premium - Payment Successful",
      html: subscriptionReceiptTemplate(user.fullName, payment.amount, endDate),
    });
  } catch (e) {
    console.error("Receipt email failed:", e.message);
  }

  return { ok: true, endDate };
}

// @desc   Verify a payment reference (called from frontend callback page)
// @route  GET /api/payments/verify/:reference
// @access Private
const verifyPayment = asyncHandler(async (req, res) => {
  const result = await verifyAndActivate(req.params.reference);
  if (!result.ok) {
    res.status(400);
    throw new Error(result.reason);
  }
  res.json({
    success: true,
    message: "Payment verified. Subscription activated for 30 days.",
    endDate: result.endDate,
  });
});

// @desc   Paystack webhook (server-to-server, source of truth for verification)
// @route  POST /api/payments/webhook
// @access Public (verified via signature)
const paystackWebhook = asyncHandler(async (req, res) => {
  const signature = req.headers["x-paystack-signature"];
  const expected = crypto
    .createHmac("sha512", process.env.PAYSTACK_WEBHOOK_SECRET)
    .update(req.rawBody || JSON.stringify(req.body))
    .digest("hex");

  if (signature !== expected) {
    return res.status(401).json({ success: false, message: "Invalid webhook signature." });
  }

  const event = req.body;
  if (event.event === "charge.success") {
    await verifyAndActivate(event.data.reference);
  }

  res.status(200).json({ received: true });
});

// @desc   Get current user's payment history
// @route  GET /api/payments/history
// @access Private
const getPaymentHistory = asyncHandler(async (req, res) => {
  const payments = await prisma.payment.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: "desc" },
  });
  res.json({ success: true, payments });
});

// @desc   Get current user's subscription status
// @route  GET /api/payments/subscription-status
// @access Private
const getSubscriptionStatus = asyncHandler(async (req, res) => {
  const activeSub = await prisma.subscription.findFirst({
    where: { userId: req.user.id, status: "ACTIVE", endDate: { gt: new Date() } },
    orderBy: { endDate: "desc" },
  });
  res.json({ success: true, isActive: !!activeSub, subscription: activeSub || null });
});

module.exports = {
  initializePayment,
  verifyPayment,
  paystackWebhook,
  getPaymentHistory,
  getSubscriptionStatus,
};
