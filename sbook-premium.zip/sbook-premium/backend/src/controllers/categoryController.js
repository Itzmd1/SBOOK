const asyncHandler = require("express-async-handler");
const prisma = require("../config/db");

const slugify = (str) =>
  str.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/\s+/g, "-");

// @desc   List all categories
// @route  GET /api/categories
// @access Public
const getCategories = asyncHandler(async (req, res) => {
  const categories = await prisma.category.findMany({
    include: { _count: { select: { books: true } } },
    orderBy: { name: "asc" },
  });
  res.json({ success: true, categories });
});

// @desc   Create category (admin)
// @route  POST /api/categories
// @access Private/Admin
const createCategory = asyncHandler(async (req, res) => {
  const { name } = req.body;
  if (!name) {
    res.status(400);
    throw new Error("Category name is required.");
  }
  const category = await prisma.category.create({ data: { name, slug: slugify(name) } });
  res.status(201).json({ success: true, category });
});

// @desc   Update category (admin)
// @route  PUT /api/categories/:id
// @access Private/Admin
const updateCategory = asyncHandler(async (req, res) => {
  const { name } = req.body;
  const category = await prisma.category.update({
    where: { id: req.params.id },
    data: { name, slug: slugify(name) },
  });
  res.json({ success: true, category });
});

// @desc   Delete category (admin)
// @route  DELETE /api/categories/:id
// @access Private/Admin
const deleteCategory = asyncHandler(async (req, res) => {
  await prisma.category.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: "Category deleted." });
});

module.exports = { getCategories, createCategory, updateCategory, deleteCategory };
