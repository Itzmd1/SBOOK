const asyncHandler = require("express-async-handler");
const prisma = require("../config/db");
const { uploadToCloudinary, deleteFromCloudinary } = require("../utils/cloudinaryUpload");

// @desc   List books (search, category filter, pagination) - metadata only, no paywall
// @route  GET /api/books
// @access Public
const getBooks = asyncHandler(async (req, res) => {
  const { search, categoryId, page = 1, limit = 12 } = req.query;

  const where = {
    isPublished: true,
    ...(categoryId ? { categoryId } : {}),
    ...(search
      ? {
          OR: [
            { title: { contains: search, mode: "insensitive" } },
            { author: { contains: search, mode: "insensitive" } },
          ],
        }
      : {}),
  };

  const [books, total] = await Promise.all([
    prisma.book.findMany({
      where,
      include: { category: true },
      orderBy: { createdAt: "desc" },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
    }),
    prisma.book.count({ where }),
  ]);

  res.json({ success: true, books, total, page: Number(page), pages: Math.ceil(total / limit) });
});

// @desc   Get single book detail (metadata visible to everyone; pdfUrl withheld if not subscribed)
// @route  GET /api/books/:id
// @access Public (pdfUrl requires subscription - see getBookFile)
const getBookById = asyncHandler(async (req, res) => {
  const book = await prisma.book.findUnique({
    where: { id: req.params.id },
    include: { category: true },
  });

  if (!book || !book.isPublished) {
    res.status(404);
    throw new Error("Book not found.");
  }

  // Never expose pdfUrl on the public detail endpoint - it's gated separately.
  const { pdfUrl, pdfPublicId, ...safeBook } = book;
  res.json({ success: true, book: safeBook });
});

// @desc   Get the actual PDF url for reading - requires an active subscription
// @route  GET /api/books/:id/read
// @access Private + requireActiveSubscription
const getBookFile = asyncHandler(async (req, res) => {
  const book = await prisma.book.findUnique({ where: { id: req.params.id } });
  if (!book) {
    res.status(404);
    throw new Error("Book not found.");
  }

  await prisma.book.update({ where: { id: book.id }, data: { viewCount: { increment: 1 } } });

  res.json({
    success: true,
    pdfUrl: book.pdfUrl,
    downloadEnabled: book.downloadEnabled,
  });
});

// @desc   Create a book (admin)
// @route  POST /api/books
// @access Private/Admin
const createBook = asyncHandler(async (req, res) => {
  const { title, author, description, categoryId, downloadEnabled } = req.body;

  if (!title || !author || !description || !categoryId) {
    res.status(400);
    throw new Error("Title, author, description and category are required.");
  }
  if (!req.files?.cover || !req.files?.pdf) {
    res.status(400);
    throw new Error("Both a cover image and a PDF file are required.");
  }

  const coverResult = await uploadToCloudinary(req.files.cover[0].buffer, "sbook/covers", "image");
  const pdfResult = await uploadToCloudinary(req.files.pdf[0].buffer, "sbook/pdfs", "raw");

  const book = await prisma.book.create({
    data: {
      title,
      author,
      description,
      categoryId,
      coverImageUrl: coverResult.secure_url,
      pdfUrl: pdfResult.secure_url,
      pdfPublicId: pdfResult.public_id,
      downloadEnabled: downloadEnabled === "true" || downloadEnabled === true,
    },
  });

  res.status(201).json({ success: true, book });
});

// @desc   Update a book (admin)
// @route  PUT /api/books/:id
// @access Private/Admin
const updateBook = asyncHandler(async (req, res) => {
  const existing = await prisma.book.findUnique({ where: { id: req.params.id } });
  if (!existing) {
    res.status(404);
    throw new Error("Book not found.");
  }

  const { title, author, description, categoryId, downloadEnabled, isPublished } = req.body;
  const data = {
    ...(title && { title }),
    ...(author && { author }),
    ...(description && { description }),
    ...(categoryId && { categoryId }),
    ...(downloadEnabled !== undefined && { downloadEnabled: downloadEnabled === "true" || downloadEnabled === true }),
    ...(isPublished !== undefined && { isPublished: isPublished === "true" || isPublished === true }),
  };

  if (req.files?.cover) {
    const coverResult = await uploadToCloudinary(req.files.cover[0].buffer, "sbook/covers", "image");
    data.coverImageUrl = coverResult.secure_url;
  }
  if (req.files?.pdf) {
    if (existing.pdfPublicId) await deleteFromCloudinary(existing.pdfPublicId, "raw").catch(() => {});
    const pdfResult = await uploadToCloudinary(req.files.pdf[0].buffer, "sbook/pdfs", "raw");
    data.pdfUrl = pdfResult.secure_url;
    data.pdfPublicId = pdfResult.public_id;
  }

  const book = await prisma.book.update({ where: { id: req.params.id }, data });
  res.json({ success: true, book });
});

// @desc   Delete a book (admin)
// @route  DELETE /api/books/:id
// @access Private/Admin
const deleteBook = asyncHandler(async (req, res) => {
  const book = await prisma.book.findUnique({ where: { id: req.params.id } });
  if (!book) {
    res.status(404);
    throw new Error("Book not found.");
  }
  if (book.pdfPublicId) await deleteFromCloudinary(book.pdfPublicId, "raw").catch(() => {});
  await prisma.book.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: "Book deleted." });
});

// @desc   Toggle bookmark on a page
// @route  POST /api/books/:id/bookmark
// @access Private
const toggleBookmark = asyncHandler(async (req, res) => {
  const { page = 1, note } = req.body;
  const existing = await prisma.bookmark.findUnique({
    where: { userId_bookId_page: { userId: req.user.id, bookId: req.params.id, page: Number(page) } },
  });

  if (existing) {
    await prisma.bookmark.delete({ where: { id: existing.id } });
    return res.json({ success: true, bookmarked: false });
  }

  const bookmark = await prisma.bookmark.create({
    data: { userId: req.user.id, bookId: req.params.id, page: Number(page), note },
  });
  res.json({ success: true, bookmarked: true, bookmark });
});

// @desc   Toggle favorite
// @route  POST /api/books/:id/favorite
// @access Private
const toggleFavorite = asyncHandler(async (req, res) => {
  const existing = await prisma.favorite.findUnique({
    where: { userId_bookId: { userId: req.user.id, bookId: req.params.id } },
  });

  if (existing) {
    await prisma.favorite.delete({ where: { id: existing.id } });
    return res.json({ success: true, favorited: false });
  }

  await prisma.favorite.create({ data: { userId: req.user.id, bookId: req.params.id } });
  res.json({ success: true, favorited: true });
});

// @desc   Update reading progress
// @route  PUT /api/books/:id/progress
// @access Private
const updateProgress = asyncHandler(async (req, res) => {
  const { currentPage, totalPages } = req.body;
  const percentage = totalPages ? Math.min(100, (currentPage / totalPages) * 100) : 0;

  const progress = await prisma.readingProgress.upsert({
    where: { userId_bookId: { userId: req.user.id, bookId: req.params.id } },
    update: { currentPage, totalPages, percentage, lastReadAt: new Date() },
    create: {
      userId: req.user.id,
      bookId: req.params.id,
      currentPage: currentPage || 1,
      totalPages: totalPages || 1,
      percentage,
    },
  });

  res.json({ success: true, progress });
});

module.exports = {
  getBooks,
  getBookById,
  getBookFile,
  createBook,
  updateBook,
  deleteBook,
  toggleBookmark,
  toggleFavorite,
  updateProgress,
};
