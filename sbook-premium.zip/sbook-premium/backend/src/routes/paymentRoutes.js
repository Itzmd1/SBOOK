const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const {
  initializePayment, verifyPayment, paystackWebhook,
  getPaymentHistory, getSubscriptionStatus,
} = require("../controllers/paymentController");

router.post("/initialize", protect, initializePayment);
router.get("/verify/:reference", protect, verifyPayment);
router.post("/webhook", paystackWebhook);
router.get("/history", protect, getPaymentHistory);
router.get("/subscription-status", protect, getSubscriptionStatus);

module.exports = router;
