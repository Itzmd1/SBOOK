const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const { requireRole } = require("../middleware/rbac");
const {
  getCategories, createCategory, updateCategory, deleteCategory,
} = require("../controllers/categoryController");

router.get("/", getCategories);
router.post("/", protect, requireRole("ADMIN"), createCategory);
router.put("/:id", protect, requireRole("ADMIN"), updateCategory);
router.delete("/:id", protect, requireRole("ADMIN"), deleteCategory);

module.exports = router;
