const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const { requireRole } = require("../middleware/rbac");
const {
  getUsers, toggleSuspendUser, getSubscribers, getPayments, getAnalytics,
} = require("../controllers/adminController");

router.use(protect, requireRole("ADMIN"));

router.get("/users", getUsers);
router.put("/users/:id/suspend", toggleSuspendUser);
router.get("/subscribers", getSubscribers);
router.get("/payments", getPayments);
router.get("/analytics", getAnalytics);

module.exports = router;
