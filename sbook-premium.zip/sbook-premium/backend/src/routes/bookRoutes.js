const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const { requireRole, requireActiveSubscription } = require("../middleware/rbac");
const upload = require("../middleware/upload");
const {
  getBooks, getBookById, getBookFile, createBook, updateBook, deleteBook,
  toggleBookmark, toggleFavorite, updateProgress,
} = require("../controllers/bookController");

router.get("/", getBooks);
router.get("/:id", getBookById);

router.get("/:id/read", protect, requireActiveSubscription, getBookFile);
router.post("/:id/bookmark", protect, requireActiveSubscription, toggleBookmark);
router.post("/:id/favorite", protect, requireActiveSubscription, toggleFavorite);
router.put("/:id/progress", protect, requireActiveSubscription, updateProgress);

router.post("/", protect, requireRole("ADMIN"), upload.fields([{ name: "cover", maxCount: 1 }, { name: "pdf", maxCount: 1 }]), createBook);
router.put("/:id", protect, requireRole("ADMIN"), upload.fields([{ name: "cover", maxCount: 1 }, { name: "pdf", maxCount: 1 }]), updateBook);
router.delete("/:id", protect, requireRole("ADMIN"), deleteBook);

module.exports = router;
