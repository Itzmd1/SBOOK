const express = require("express");
const router = express.Router();
const { authLimiter } = require("../middleware/rateLimiter");
const { protect } = require("../middleware/auth");
const {
  register, verifyEmail, resendVerification, login, logout,
  forgotPassword, resetPassword, getMe,
} = require("../controllers/authController");

router.post("/register", authLimiter, register);
router.get("/verify-email/:token", verifyEmail);
router.post("/resend-verification", authLimiter, resendVerification);
router.post("/login", authLimiter, login);
router.post("/logout", protect, logout);
router.post("/forgot-password", authLimiter, forgotPassword);
router.post("/reset-password/:token", authLimiter, resetPassword);
router.get("/me", protect, getMe);

module.exports = router;
