const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const upload = require("../middleware/upload");
const {
  updateProfile, changePassword, getSavedBooks,
  getContinueReading, getReadingStats, getNotifications,
} = require("../controllers/userController");

router.put("/profile", protect, upload.single("avatar"), updateProfile);
router.put("/change-password", protect, changePassword);
router.get("/saved-books", protect, getSavedBooks);
router.get("/continue-reading", protect, getContinueReading);
router.get("/stats", protect, getReadingStats);
router.get("/notifications", protect, getNotifications);

module.exports = router;
