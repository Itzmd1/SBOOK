const prisma = require("../config/db");
const { sendEmail, renewalReminderTemplate } = require("../utils/sendEmail");

/**
 * Runs daily via cron:
 *  1. Marks ACTIVE subscriptions past their endDate as EXPIRED.
 *  2. Emails users whose subscription expires within the next 3 days (once).
 */
async function runExpirySweep() {
  const now = new Date();

  const expired = await prisma.subscription.updateMany({
    where: { status: "ACTIVE", endDate: { lt: now } },
    data: { status: "EXPIRED" },
  });
  if (expired.count) console.log(`Expired ${expired.count} subscription(s).`);

  const soon = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
  const upcoming = await prisma.subscription.findMany({
    where: { status: "ACTIVE", endDate: { gte: now, lte: soon }, reminderSent: false },
    include: { user: true },
  });

  for (const sub of upcoming) {
    try {
      await sendEmail({
        to: sub.user.email,
        subject: "Your SBook Premium subscription is expiring soon",
        html: renewalReminderTemplate(sub.user.fullName, sub.endDate),
      });
      await prisma.subscription.update({ where: { id: sub.id }, data: { reminderSent: true } });
    } catch (err) {
      console.error(`Reminder email failed for ${sub.user.email}:`, err.message);
    }
  }
}

module.exports = { runExpirySweep };
