require("dotenv").config();
const bcrypt = require("bcryptjs");
const prisma = require("../config/db");

async function seedAdmin() {
  const email = (process.env.ADMIN_EMAIL || "admin@sbook.com").toLowerCase();
  const password = process.env.ADMIN_PASSWORD || "Admin@12345";
  const fullName = process.env.ADMIN_NAME || "SBook Admin";

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    console.log(`Admin account already exists: ${email}`);
    return;
  }

  const hashedPassword = await bcrypt.hash(password, 12);
  await prisma.user.create({
    data: {
      fullName,
      email,
      password: hashedPassword,
      role: "ADMIN",
      isEmailVerified: true,
    },
  });

  console.log(`✅ Admin account created: ${email}`);
  console.log(`   Change this password after first login in production.`);
}

seedAdmin()
  .catch((err) => {
    console.error("Failed to seed admin:", err);
    process.exit(1);
  })
  .finally(() => process.exit(0));
