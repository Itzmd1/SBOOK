require("dotenv").config();
const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const hpp = require("hpp");
const xssClean = require("xss-clean");
const mongoSanitize = require("express-mongo-sanitize");
const cron = require("node-cron");

const { apiLimiter } = require("./middleware/rateLimiter");
const { notFound, errorHandler } = require("./middleware/errorHandler");
const { runExpirySweep } = require("./scripts/subscriptionSweep");

const authRoutes = require("./routes/authRoutes");
const bookRoutes = require("./routes/bookRoutes");
const categoryRoutes = require("./routes/categoryRoutes");
const paymentRoutes = require("./routes/paymentRoutes");
const userRoutes = require("./routes/userRoutes");
const adminRoutes = require("./routes/adminRoutes");

const app = express();

// Trust reverse proxy (needed on most hosts for secure cookies / correct client IPs behind HTTPS-terminating LB)
app.set("trust proxy", 1);

// --- Security middleware ---
app.use(helmet()); // sensible security headers
app.use(
  cors({
    origin: process.env.CLIENT_URL,
    credentials: true,
  })
);

// Paystack webhook needs the raw body for signature verification, so capture it
// before json parsing strips/reformats it.
app.use(
  express.json({
    limit: "2mb",
    verify: (req, res, buf) => {
      req.rawBody = buf.toString();
    },
  })
);
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(mongoSanitize()); // strips NoSQL-injection-style operators from input
app.use(xssClean()); // sanitizes user input against XSS
app.use(hpp()); // guards against HTTP parameter pollution
app.use(apiLimiter); // global rate limit

// SQL injection protection is handled by Prisma's parameterized queries throughout the app.

// --- Health check ---
app.get("/api/health", (req, res) => res.json({ success: true, message: "SBook Premium API is running" }));

// --- Routes ---
app.use("/api/auth", authRoutes);
app.use("/api/books", bookRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/users", userRoutes);
app.use("/api/admin", adminRoutes);

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`SBook Premium API listening on port ${PORT} [${process.env.NODE_ENV}]`);
});

// Daily job: expire subscriptions past endDate + send renewal reminders 3 days before expiry
cron.schedule("0 2 * * *", () => {
  runExpirySweep().catch((err) => console.error("Subscription sweep failed:", err));
});

module.exports = app;
