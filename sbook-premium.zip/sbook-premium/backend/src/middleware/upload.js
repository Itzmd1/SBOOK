const multer = require("multer");

const storage = multer.memoryStorage();

function fileFilter(req, file, cb) {
  if (file.fieldname === "cover") {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("Cover must be an image file."));
    }
  }
  if (file.fieldname === "pdf") {
    if (file.mimetype !== "application/pdf") {
      return cb(new Error("Book file must be a PDF."));
    }
  }
  if (file.fieldname === "avatar" && !file.mimetype.startsWith("image/")) {
    return cb(new Error("Avatar must be an image file."));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 25 * 1024 * 1024 }, // 25MB
});

module.exports = upload;
