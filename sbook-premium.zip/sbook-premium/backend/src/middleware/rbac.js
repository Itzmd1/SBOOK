const asyncHandler = require("express-async-handler");
const prisma = require("../config/db");

/** Restrict a route to one or more roles, e.g. requireRole("ADMIN") */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      res.status(403);
      throw new Error("You do not have permission to perform this action.");
    }
    next();
  };
}

/**
 * Blocks access to book content unless the user has an ACTIVE, non-expired
 * subscription. Admins bypass this check. This is the core paywall gate.
 */
const requireActiveSubscription = asyncHandler(async (req, res, next) => {
  if (req.user.role === "ADMIN") return next();

  const activeSub = await prisma.subscription.findFirst({
    where: {
      userId: req.user.id,
      status: "ACTIVE",
      endDate: { gt: new Date() },
    },
    orderBy: { endDate: "desc" },
  });

  if (!activeSub) {
    res.status(402); // Payment Required
    throw new Error("An active subscription is required to access this content.");
  }

  req.subscription = activeSub;
  next();
});

module.exports = { requireRole, requireActiveSubscription };
