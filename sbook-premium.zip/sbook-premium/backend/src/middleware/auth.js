const jwt = require("jsonwebtoken");
const asyncHandler = require("express-async-handler");
const prisma = require("../config/db");

/**
 * Verifies the JWT (from httpOnly cookie or Authorization header),
 * attaches the authenticated user to req.user, and blocks suspended accounts.
 */
const protect = asyncHandler(async (req, res, next) => {
  let token = req.cookies?.token;

  if (!token && req.headers.authorization?.startsWith("Bearer ")) {
    token = req.headers.authorization.split(" ")[1];
  }

  if (!token) {
    res.status(401);
    throw new Error("Not authenticated. Please log in.");
  }

  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    res.status(401);
    throw new Error("Session expired or invalid. Please log in again.");
  }

  const user = await prisma.user.findUnique({ where: { id: decoded.id } });

  if (!user) {
    res.status(401);
    throw new Error("User no longer exists.");
  }

  if (user.isSuspended) {
    res.status(403);
    throw new Error("Your account has been suspended. Contact support.");
  }

  req.user = user;
  next();
});

module.exports = { protect };
